export class Catch {
    constructor(angler, weight, species, location, bait, captureTime) {
        this.angler = angler;
        this.weight = weight;
        this.species = species;
        this.location = location;
        this.bait = bait;
        this.captureTime = captureTime;
    }
}